"""
Kalshi BTC 15-minute auto-trader  (unofficial, educational)
-----------------------------------------------------------
NOT FINANCIAL ADVICE. Not affiliated with or endorsed by Kalshi. Trading can lose
money, including everything you put in. Use at your own risk. Start with DRY_RUN = True.

What it does:
  * Watches the current KXBTC15M market (Bitcoin up/down, 15 minutes).
  * From 2:30 left, waits for one side (Up or Down) to stay between ENTRY_MIN and
    ENTRY_MAX for HOLD_SECONDS in a row, then buys it (immediate-or-cancel orders).
  * Stop loss: sells if your side's bid falls to STOP_PRICE (or STOP_LOSS_PCT below
    your entry, depending on STOP_MODE).
  * Bet size = STARTING_STAKE + saved profit/loss (COMPOUND), never above MAX_STAKE.
  * Stops opening trades for the day once DAILY_LOSS_LIMIT is reached.
  * Prints a TRADE REPORT per market and keeps a daily counter and a CSV log.

Setup: see README.md.  Credentials come from the KALSHI_KEY_ID and KALSHI_KEY_FILE
environment variables, or edit the two lines below. NEVER commit your private key.
"""

import base64
import csv
import os
import json
import math
import time
import uuid
from datetime import datetime, timezone

import requests
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding

# ----------------------------- SETTINGS --------------------------------
KEY_ID = os.environ.get("KALSHI_KEY_ID", "PASTE-YOUR-KEY-ID")
PRIVATE_KEY_PATH = os.environ.get("KALSHI_KEY_FILE", "kalshi_key.key")   # path to your private key file

BASE_URL = "https://api.elections.kalshi.com/trade-api/v2"
# Demo (fake money): "https://demo-api.kalshi.co/trade-api/v2"

SERIES_TICKER = "KXBTC15M"   # BTC 15-minute series. Verify this on Kalshi's site.

STARTING_STAKE = 5.0         # dollars
COMPOUND = True              # True: stake + all profit/loss so far. False: flat stake.
DAILY_LOSS_LIMIT = 10.0      # final stop for the day: no new trades once you're down this many dollars
                             # today (0 = off). The bet also shrinks so a full loss can't pass the limit.
                             # Resets at midnight. Open trades still get their normal stop loss.
MAX_STAKE = 10.0             # never bet more than this per trade. Winnings above it stay safe in your
                             # account, and they refill the bet back up to this cap after a loss.
FEE_BUFFER = 1.0             # 1.0 = bet the full bankroll and let Kalshi take fees as they come
                             # (0.97 would hold back 3% for fees)
ROUND_MODE = "nearest"       # "nearest" = closest whole number of contracts (can land a bit OVER the stake)
                             # "down"    = never spend more than the stake (can land well under it)

WINDOW_START_SEC = 150       # 2:30 left
WINDOW_END_SEC = 30           # 0 = keep watching until the market closes (set e.g. 30 to stop entering with 30s left)
ENTRY_MIN = 90               # first entry needs >= 90
ENTRY_MAX = 95               # don't chase above this
REENTRY_MIN = 90             # after a stop-out, re-entry needs >= 90 too
MAX_ENTRIES_PER_MARKET = 2   # 1 entry + 1 re-entry after a stop-out

STOP_MODE = "price"          # "price"   = sell when your side's price falls to STOP_PRICE
                             # "percent" = sell when it falls STOP_LOSS_PCT below your entry
STOP_PRICE = 70              # used when STOP_MODE = "price" (70 = sell when it hits 70%)
STOP_LOSS_PCT = 12           # used when STOP_MODE = "percent"
STOP_CONFIRM_READS = 2       # bid must be at/below stop on this many reads in a row
                             # (1 = react instantly, 2 = ignores a single bad quote)

POLL_SECONDS = 1
HOLD_SECONDS = 10            # a side must stay inside your 90-95 range this many seconds IN A ROW before buying
                             # (0 = buy the moment it appears)
MIN_CUSHION_USD = 0          # 0 = just RECORD how far BTC is past the target; e.g. 40 = only buy when BTC is
                             # at least $40 on the winning side of the target line
BTC_PRICE_URL = "https://api.coinbase.com/v2/prices/BTC-USD/spot"   # live BTC price (not Kalshi's exact index)
TRADE_CSV = "kalshi_trades.csv"   # one row per market, for checking later what worked
BUY_SLIPPAGE = 4             # willing to pay up to 4c above the displayed ask (IOC fills at best asks)
MAX_ATTEMPTS = 3            # unfilled buy attempts per market before giving up
STATS_FILE = "kalshi_daily_stats.json"   # daily counter is saved here
COMPOUND_FILE = "kalshi_compound.json"   # running profit/loss that compounding uses (survives restarts)
DRY_RUN = True
# ------------------------------------------------------------------------

if KEY_ID == "PASTE-YOUR-KEY-ID":
    raise SystemExit("Set your Kalshi Key ID: edit KEY_ID near the top of kalshi_bot.py "
                     "or set the KALSHI_KEY_ID environment variable.")
if not os.path.exists(PRIVATE_KEY_PATH):
    raise SystemExit(f"Private key file not found: {PRIVATE_KEY_PATH}\n"
                     "Put your Kalshi private key file there, or set KALSHI_KEY_FILE.")

with open(PRIVATE_KEY_PATH, "rb") as f:
    PRIVATE_KEY = serialization.load_pem_private_key(f.read(), password=None)

session = requests.Session()


def signed_headers(method: str, path: str) -> dict:
    ts = str(int(time.time() * 1000))
    msg = (ts + method.upper() + path.split("?")[0]).encode()
    sig = PRIVATE_KEY.sign(
        msg,
        padding.PSS(mgf=padding.MGF1(hashes.SHA256()),
                    salt_length=padding.PSS.DIGEST_LENGTH),
        hashes.SHA256(),
    )
    return {
        "KALSHI-ACCESS-KEY": KEY_ID,
        "KALSHI-ACCESS-TIMESTAMP": ts,
        "KALSHI-ACCESS-SIGNATURE": base64.b64encode(sig).decode(),
        "Content-Type": "application/json",
    }


def api(method: str, endpoint: str, params=None, body=None):
    path = "/trade-api/v2" + endpoint
    r = session.request(method, BASE_URL + endpoint, params=params, json=body,
                        headers=signed_headers(method, path), timeout=10)
    r.raise_for_status()
    return r.json()


def cents(market: dict, field: str):
    """Prices come back in cents or as dollar strings depending on the field."""
    if market.get(field) is not None:
        return round(float(market[field]), 2)
    d = market.get(field + "_dollars")
    return round(float(d) * 100, 2) if d is not None else None


def get_current_market():
    data = api("GET", "/markets", params={"series_ticker": SERIES_TICKER,
                                          "status": "open", "limit": 20})
    markets = data.get("markets", [])
    return min(markets, key=lambda m: m["close_time"]) if markets else None


def seconds_left(market: dict) -> float:
    close = datetime.fromisoformat(market["close_time"].replace("Z", "+00:00"))
    return (close - datetime.now(timezone.utc)).total_seconds()


def place_order(ticker, action, side, count, price_cents):
    """
    Kalshi V2 order endpoint. V2 quotes everything on the YES side:
      buy UP   = bid YES at p           sell UP   = ask YES at p
      buy DOWN = ask YES at (100 - p)   sell DOWN = bid YES at (100 - p)
    Orders are immediate-or-cancel, so nothing is left resting on the book.
    """
    if action == "buy":
        p = min(99, math.ceil(price_cents - 1e-9))   # round UP so it can fill
    else:
        p = max(1, int(price_cents))                 # lowest price we'll accept
    yes_price = p if side == "yes" else 100 - p
    if action == "buy":
        book_side = "bid" if side == "yes" else "ask"
    else:
        book_side = "ask" if side == "yes" else "bid"

    body = {
        "ticker": ticker,
        "client_order_id": str(uuid.uuid4()),
        "side": book_side,
        "count": f"{count:.2f}",
        "price": f"{yes_price / 100:.2f}",
        "time_in_force": "immediate_or_cancel",
        "self_trade_prevention_type": "taker_at_cross",
    }
    if action == "sell":
        body["reduce_only"] = True   # a sell can only close what you hold
    if DRY_RUN:
        print(f"  [DRY RUN] {action} {side.upper()} would send: {body}")
        return {"dry_run": True}
    print(f"  sending order: {body}")
    resp = api("POST", "/portfolio/events/orders", body=body)
    print(f"  order reply: {resp}")
    return resp


def fill_price_cents(resp, side, fallback):
    """Real average price paid/received, in cents of OUR side (falls back to the quote)."""
    try:
        avg = float(resp["average_fill_price"]) * 100
        return round(avg if side == "yes" else 100 - avg, 2)
    except Exception:
        return fallback


def buy_with_fallback(ticker, side, contracts, limit):
    """Place a buy. If Kalshi says insufficient balance, retry with smaller sizes
    (e.g. 5 -> 2 -> 1) so we learn what size it will actually accept."""
    n = contracts
    while True:
        try:
            return place_order(ticker, "buy", side, n, limit), n
        except requests.HTTPError as e:
            text = e.response.text if e.response is not None else ""
            if "insufficient_balance" in text and n > 1:
                smaller = max(1, n // 2)
                print(f"  Kalshi says insufficient balance for {n} contracts -> trying {smaller}...")
                n = smaller
                continue
            raise


def filled(resp, requested):
    """How many contracts actually filled."""
    if DRY_RUN:
        return requested
    try:
        return int(round(float(resp.get("fill_count", 0))))
    except Exception:
        return 0


def cancel_order(resp):
    try:
        oid = resp.get("order", {}).get("order_id")
        if oid and not DRY_RUN:
            api("DELETE", f"/portfolio/orders/{oid}")
    except Exception as e:
        print(f"  cancel failed: {e}")


def held_contracts(ticker) -> int:
    data = api("GET", "/portfolio/positions", params={"ticker": ticker})
    for p in data.get("market_positions", []):
        if p["ticker"] == ticker:
            return abs(int(p.get("position", 0)))
    return 0


def get_balance_cents() -> int:
    return int(api("GET", "/portfolio/balance")["balance"])


def get_shard_balances():
    """Kalshi keeps a separate balance per 'exchange shard'. Returns
    (total_cents, {shard_index: cents}). Orders can only use money on the
    shard the market lives on (crypto markets live on shard 2)."""
    d = api("GET", "/portfolio/balance")
    total = int(d["balance"])
    shards = {}
    for b in d.get("balance_breakdown") or []:
        shards[int(b["exchange_index"])] = int(round(float(b["balance"]) * 100))
    return total, shards


def shard_balance_cents(idx):
    total, shards = get_shard_balances()
    return shards.get(int(idx), 0) if shards else total


FUND_URL = "https://kalshi.com/account/exchange-indexes"


def market_result(ticker):
    """Returns (settled, result) where result is 'yes', 'no' or None."""
    m = api("GET", f"/markets/{ticker}")["market"]
    res = m.get("result")
    settled = res in ("yes", "no") or m.get("status") in ("settled", "finalized")
    return settled, res


def market_settled(ticker) -> bool:
    return market_result(ticker)[0]


# ------------------------- REPORTING / DAILY COUNTER ---------------------
def now_str() -> str:
    return datetime.now().strftime("%H:%M:%S")


def money(c) -> str:
    """cents -> '+$1.23' / '-$0.40'"""
    return f"{'+' if c >= 0 else '-'}${abs(c) / 100:.2f}"


def save_stats(s: dict):
    try:
        with open(STATS_FILE, "w") as f:
            json.dump(s, f)
    except Exception as e:
        print(f"\n  could not save stats: {e}")


def compound_pnl_cents() -> int:
    """Total profit/loss (cents) from all LIVE trades since the compound file was created."""
    try:
        with open(COMPOUND_FILE) as f:
            return int(json.load(f).get("pnl_cents", 0))
    except Exception:
        return 0


def add_compound_pnl(delta_cents: int):
    try:
        with open(COMPOUND_FILE, "w") as f:
            json.dump({"pnl_cents": compound_pnl_cents() + int(delta_cents)}, f)
    except Exception as e:
        print(f"\n  could not save compounding file: {e}")


def load_stats(balance_cents: int) -> dict:
    """Load today's counter, or start a fresh one if it's a new day / no file."""
    today = datetime.now().date().isoformat()
    try:
        with open(STATS_FILE) as f:
            s = json.load(f)
        if s.get("date") == today:
            return s
    except Exception:
        pass
    s = {"date": today, "start_balance_cents": balance_cents,
         "trades": 0, "wins": 0, "losses": 0, "pnl_cents": 0}
    save_stats(s)
    return s


def stats_line(s: dict) -> str:
    start = s["start_balance_cents"]
    pct = (s["pnl_cents"] / start * 100) if start else 0.0
    return (f"TODAY {s['date']}: {s['trades']} trades | {s['wins']}W / {s['losses']}L | "
            f"{money(s['pnl_cents'])} ({pct:+.1f}% of day-start balance ${start / 100:.2f})")


def get_btc_price():
    """Live BTC price from a public feed. Kalshi settles on CF Benchmarks' BRTI, which differs by a few
    dollars, so treat this as approximate. Returns None if the feed can't be reached."""
    try:
        r = requests.get(BTC_PRICE_URL, timeout=3)
        r.raise_for_status()
        return float(r.json()["data"]["amount"])
    except Exception:
        return None


def get_target(market):
    """The 'price to beat' on the Kalshi page (the market's strike), if the API exposes it."""
    for field in ("floor_strike", "cap_strike", "functional_strike"):
        v = market.get(field)
        if v not in (None, ""):
            try:
                return float(v)
            except (TypeError, ValueError):
                pass
    return None


def cushion_text(btc, target, cushion):
    if btc is None or target is None:
        return "BTC/target unavailable"
    return f"BTC ${btc:,.2f} vs target ${target:,.2f} (cushion {'+' if cushion >= 0 else '-'}${abs(cushion):,.2f})"


CSV_FIELDS = ["time", "mode", "market", "side", "entry_price_c", "seconds_left", "btc_usd", "target_usd",
              "cushion_usd", "stop_loss_hit", "market_result", "held_to_end_would_win", "pnl_usd"]


def log_csv(row: dict):
    try:
        path = os.path.join(os.path.dirname(os.path.abspath(__file__)), TRADE_CSV)
        is_new = not os.path.exists(path)
        with open(path, "a", newline="") as f:
            w = csv.DictWriter(f, fieldnames=CSV_FIELDS)
            if is_new:
                w.writeheader()
            w.writerow(row)
    except Exception as e:
        print(f"\n  (could not write {TRADE_CSV}: {e} -- is it open in Excel?)")


def new_report(ticker, balance_before):
    return {"ticker": ticker, "balance_before": balance_before, "events": [],
            "fills": 0, "unfilled": 0, "cost": 0.0, "last_check": 0.0}


def finalize_report(r: dict, stats: dict) -> bool:
    """Print the trade report once the market has settled. Returns True when done."""
    if r["fills"] == 0:
        print(f"\n[{now_str()}] {r['ticker']}: no trade taken "
              f"({r['unfilled']} unfilled buy attempts).")
        for e in r["events"]:
            print(f"  {e}")
        return True

    settled, res = market_result(r["ticker"])
    if not settled:
        return False
    time.sleep(2)   # give the payout a moment to land in the balance

    before = r["balance_before"]
    after = before if DRY_RUN else get_balance_cents()
    pnl = after - before
    pct = (pnl / r["cost"] * 100) if r["cost"] else 0.0
    outcome = {"yes": "UP", "no": "DOWN"}.get(res, "unknown")

    if not DRY_RUN:
        add_compound_pnl(pnl)
        stats["trades"] += 1
        if pnl > 0:
            stats["wins"] += 1
        elif pnl < 0:
            stats["losses"] += 1
        stats["pnl_cents"] += pnl
        save_stats(stats)

    first = (r.get("entries") or [{}])[0]
    if first:
        side_txt = "UP" if first["side"] == "yes" else "DOWN"
        log_csv({
            "time": now_str(), "mode": "DRY" if DRY_RUN else "LIVE", "market": r["ticker"],
            "side": side_txt, "entry_price_c": first["fill_px"], "seconds_left": first["left"],
            "btc_usd": first["btc"] if first["btc"] is not None else "",
            "target_usd": first["target"] if first["target"] is not None else "",
            "cushion_usd": round(first["cushion"], 2) if first["cushion"] is not None else "",
            "stop_loss_hit": any("STOP LOSS" in e for e in r["events"]),
            "market_result": outcome,
            "held_to_end_would_win": (side_txt == outcome),
            "pnl_usd": round(pnl / 100, 2),
        })

    bar = "=" * 70
    print(f"\n{bar}\n TRADE REPORT  {r['ticker']}" + ("   (DRY RUN - no real money)" if DRY_RUN else ""))
    print(bar)
    for e in r["events"]:
        print(f"  {e}")
    if r["unfilled"]:
        print(f"  ({r['unfilled']} buy attempts did not fill along the way)")
    print(f"  Market settled: {outcome}")
    print(f"  Balance: ${before / 100:.2f} -> ${after / 100:.2f}")
    print(f"  Trade P/L: {money(pnl)} ({pct:+.1f}% on ~${r['cost'] / 100:.2f} bought)")
    print(f"  {stats_line(stats)}")
    print(bar)
    return True
# ------------------------------------------------------------------------


def main():
    print(f"Bot started. DRY_RUN={DRY_RUN}  series={SERIES_TICKER}")
    entries = {}              # ticker -> number of entries made
    hold = {"ticker": None, "side": None, "since": 0.0}   # how long a side has stayed in range
    last_cushion_msg = {}     # ticker -> time of last "waiting for cushion" message
    limit_msg_date = None     # so the daily-limit message prints once per day
    attempts = {}             # ticker -> unfilled buy attempts
    stopped_out = set()       # tickers where the stop loss fired
    position = None           # {"ticker","side","count","entry_price"}
    pending_ticker = None     # last market we hold/held, waiting for payout
    reports = {}              # ticker -> trade report waiting to be printed
    stop_hits = 0
    shown_shards = False
    start_balance = get_balance_cents()
    print(f"Account balance at start: ${start_balance/100:.2f} | stake ${STARTING_STAKE:.2f}")
    for label, ep in (("balance reply", "/portfolio/balance"),
                      ("subaccount balances", "/portfolio/subaccounts/balances")):
        try:
            print(f"  Kalshi {label}: {api('GET', ep)}")
        except Exception as e:
            print(f"  (could not read {label}: {e})")
    stats = load_stats(start_balance)
    print(stats_line(stats))
    if DAILY_LOSS_LIMIT > 0:
        left_c = int(DAILY_LOSS_LIMIT * 100) + stats["pnl_cents"]
        print(f"Daily loss limit: ${DAILY_LOSS_LIMIT:.2f}  (today {money(stats['pnl_cents'])} -> "
              f"${max(0, left_c) / 100:.2f} left before the bot stops for the day)")
    if COMPOUND:
        saved = compound_pnl_cents()
        raw_bank = max(0, STARTING_STAKE * 100 + saved)
        print(f"Compounding bankroll: ${STARTING_STAKE:.2f} stake {money(saved)} saved profit/loss "
              f"= ${raw_bank / 100:.2f}  -> next bet uses ${min(raw_bank, MAX_STAKE * 100) / 100:.2f} "
              f"(cap ${MAX_STAKE:.2f}; delete {COMPOUND_FILE} to reset)")

    while True:
        try:
            market = get_current_market()
            if not market:
                time.sleep(5)
                continue

            ticker = market["ticker"]
            left = seconds_left(market)

            if not shown_shards:
                shown_shards = True
                try:
                    total, shards = get_shard_balances()
                    idx = market.get("exchange_index")
                    print("\nYour money by Kalshi exchange shard: " +
                          ", ".join(f"shard {i}: ${c / 100:.2f}" for i, c in sorted(shards.items())))
                    if idx is not None:
                        have = shards.get(int(idx), 0)
                        print(f"This market ({SERIES_TICKER}) trades on shard {idx}, which has ${have / 100:.2f}.")
                        if have < STARTING_STAKE * 100 and not DRY_RUN:
                            print(f"  >> NOT ENOUGH on shard {idx} for a ${STARTING_STAKE:.2f} stake. "
                                  f"Move money there first: {FUND_URL}")
                except Exception as e:
                    print(f"  (could not read shard balances: {e})")
                print(f"Target price from Kalshi (floor_strike): {get_target(market)}  |  "
                      f"live BTC price feed: {get_btc_price()}")

            # new day -> fresh counter
            if stats["date"] != datetime.now().date().isoformat():
                stats = load_stats(get_balance_cents())

            # print reports for markets that have closed and paid out
            for t in [t for t in reports if t != ticker]:
                if time.time() - reports[t]["last_check"] < 3:
                    continue
                reports[t]["last_check"] = time.time()
                if finalize_report(reports[t], stats):
                    del reports[t]

            # ---------------- STOP LOSS ----------------
            if position and position["ticker"] != ticker:
                position, stop_hits = None, 0   # old market expired
            if position:
                bid = cents(market, f"{position['side']}_bid")
                if STOP_MODE == "price":
                    stop_price = min(STOP_PRICE, position["entry_price"] - 1)
                else:
                    stop_price = position["entry_price"] * (1 - STOP_LOSS_PCT / 100)
                if bid is not None and bid <= stop_price:
                    stop_hits += 1
                else:
                    stop_hits = 0
                if stop_hits >= STOP_CONFIRM_READS:
                    print(f"\nSTOP LOSS: {position['side']} bid={bid} <= {stop_price:.1f} "
                          f"(entry {position['entry_price']}c, mode={STOP_MODE}). Selling.")
                    resp = place_order(ticker, "sell", position["side"], position["count"], 1)
                    # sell at the lowest price = sell into whatever bids exist right now
                    sold = filled(resp, position["count"])
                    remaining = position["count"] - sold
                    rep = reports.get(ticker)
                    if rep:
                        rep["events"].append(
                            f"{now_str()}  STOP LOSS  sold {sold} of {position['count']} "
                            f"{'UP' if position['side'] == 'yes' else 'DOWN'} "
                            f"(bid {bid}c <= stop {stop_price:.1f}c, {left:.0f}s left)")
                    if remaining <= 0:
                        position, stop_hits = None, 0
                        stopped_out.add(ticker)
                        pending_ticker = None   # money already back in balance
                    else:
                        print(f"  {remaining} contracts still held; retrying.")
                        position["count"] = remaining

            # ---------------- ENTRY / RE-ENTRY ----------------
            hold_note = ""
            n = entries.get(ticker, 0)
            in_window = WINDOW_END_SEC <= left <= WINDOW_START_SEC
            remaining_c = int(DAILY_LOSS_LIMIT * 100) + stats["pnl_cents"]   # how much more can be lost today
            day_over = DAILY_LOSS_LIMIT > 0 and remaining_c <= 0
            if day_over:
                hold_note = " | DAILY LOSS LIMIT HIT - no new trades today"
                if limit_msg_date != stats["date"]:
                    limit_msg_date = stats["date"]
                    print(f"\nDAILY LOSS LIMIT REACHED: down {money(-stats['pnl_cents'])[1:]} today "
                          f"(limit ${DAILY_LOSS_LIMIT:.2f}). No new trades until tomorrow; "
                          f"open trades keep their stop loss.")
            can_enter = (
                in_window and position is None and n < MAX_ENTRIES_PER_MARKET
                and (n == 0 or ticker in stopped_out) and not day_over
            )
            if can_enter:
                threshold = ENTRY_MIN if n == 0 else REENTRY_MIN
                yes_ask, no_ask = cents(market, "yes_ask"), cents(market, "no_ask")
                side = price = None
                if yes_ask is not None and threshold <= yes_ask <= ENTRY_MAX:
                    side, price = "yes", yes_ask
                elif no_ask is not None and threshold <= no_ask <= ENTRY_MAX:
                    side, price = "no", no_ask

                # orders can't go above 99c, so a quote of 99c or more can never fill
                if side and price >= 99:
                    print(f"\nSKIPPING {ticker}: {'UP' if side == 'yes' else 'DOWN'} is already {price}c "
                          f"(max order price is 99c, and the win would be under 1c per contract).")
                    entries[ticker] = MAX_ENTRIES_PER_MARKET
                    side = None

                # 1) price must STAY in range for HOLD_SECONDS in a row (ignores quick spikes)
                hold_note = ""
                if not side:
                    hold.update(ticker=None, side=None)           # left the range -> clock restarts
                elif HOLD_SECONDS > 0:
                    now_t = time.time()
                    if hold["ticker"] != ticker or hold["side"] != side:
                        hold.update(ticker=ticker, side=side, since=now_t)
                    held = now_t - hold["since"]
                    if held < HOLD_SECONDS:
                        hold_note = f" | HOLD {held:.0f}/{HOLD_SECONDS}s {'UP' if side == 'yes' else 'DOWN'}@{price}c"
                        side = None

                # 2) how far BTC is past the target (always recorded; blocks buys if MIN_CUSHION_USD > 0)
                btc = target = cushion = None
                if side:
                    btc, target = get_btc_price(), get_target(market)
                    if btc is not None and target is not None:
                        cushion = (btc - target) if side == "yes" else (target - btc)
                    if MIN_CUSHION_USD > 0 and (cushion is None or cushion < MIN_CUSHION_USD):
                        if time.time() - last_cushion_msg.get(ticker, 0) >= 10:
                            last_cushion_msg[ticker] = time.time()
                            print(f"\nWAITING on {ticker}: {'UP' if side == 'yes' else 'DOWN'} is {price}c but "
                                  f"{cushion_text(btc, target, cushion)}; need at least ${MIN_CUSHION_USD:,.0f}.")
                        hold_note = f" | WAIT cushion<${MIN_CUSHION_USD:,.0f}"
                        side = None

                # make sure the previous market has paid out before sizing
                if side and pending_ticker and pending_ticker != ticker:
                    if market_settled(pending_ticker):
                        pending_ticker = None
                    else:
                        print(f"\nSkipping {ticker}: previous trade not paid out yet.")
                        entries[ticker] = MAX_ENTRIES_PER_MARKET
                        side = None

                if side:
                    balance = get_balance_cents()
                    # balance before the FIRST buy in this market = baseline for P/L
                    report = reports.setdefault(ticker, new_report(ticker, balance))
                    bankroll = (max(0, STARTING_STAKE * 100 + compound_pnl_cents())
                                if COMPOUND else STARTING_STAKE * 100)
                    bankroll = min(bankroll, MAX_STAKE * 100)       # the cap
                    if DAILY_LOSS_LIMIT > 0:
                        bankroll = min(bankroll, max(0, remaining_c))   # a total loss stays inside the daily limit
                        if bankroll < price:
                            print(f"\nSKIPPING {ticker}: only ${max(0, remaining_c) / 100:.2f} left before today's "
                                  f"${DAILY_LOSS_LIMIT:.2f} loss limit - too little for one contract.")
                            entries[ticker] = MAX_ENTRIES_PER_MARKET
                            continue
                    usable = balance                      # money this market can actually use
                    idx = market.get("exchange_index")
                    if idx is not None and not DRY_RUN:
                        try:
                            usable = shard_balance_cents(idx)
                        except Exception:
                            usable = balance
                    limit = min(99, price + BUY_SLIPPAGE)
                    budget = (bankroll if DRY_RUN else min(bankroll, usable)) * FEE_BUFFER
                    raw = budget / price
                    contracts = int(round(raw)) if ROUND_MODE == "nearest" else int(raw)
                    if contracts < 1 and budget >= price:
                        contracts = 1
                    if not DRY_RUN:                       # the order holds cash at the LIMIT price
                        contracts = min(contracts, int(usable // limit))
                    if contracts < 1:
                        if usable < balance:
                            print(f"\nSKIPPING {ticker}: this market trades on shard {idx}, which has only "
                                  f"${usable / 100:.2f} (your other ${(balance - usable) / 100:.2f} is on other shards).")
                            print(f"  Move money to shard {idx} here, then the bot will trade: {FUND_URL}")
                            report["events"].append(f"{now_str()}  skipped: only ${usable / 100:.2f} on shard {idx}")
                            entries[ticker] = MAX_ENTRIES_PER_MARKET
                            continue
                        print(f"\nBankroll ${bankroll/100:.2f} too small to buy. Stopping.")
                        break
                    label = "ENTRY" if n == 0 else "RE-ENTRY"
                    print(f"\n{label}: {ticker} {'UP' if side == 'yes' else 'DOWN'} @ {price}c, "
                          f"{left:.0f}s left | bankroll ${bankroll/100:.2f} -> {contracts} contracts")
                    print(f"  {cushion_text(btc, target, cushion)}")
                    try:
                        resp, contracts = buy_with_fallback(ticker, side, contracts, limit)
                    except requests.HTTPError as e:
                        print(f"\n  ORDER REJECTED by Kalshi: {e.response.text}")
                        print("  Skipping this market so it doesn't keep retrying.")
                        report["events"].append(f"{now_str()}  ORDER REJECTED by Kalshi: {e.response.text}")
                        entries[ticker] = MAX_ENTRIES_PER_MARKET
                        continue
                    count = filled(resp, contracts)
                    if count == 0:
                        attempts[ticker] = attempts.get(ticker, 0) + 1
                        report["unfilled"] += 1
                        print(f"  Not filled. Attempt {attempts[ticker]} of {MAX_ATTEMPTS}.")
                        print(f"  quotes: yes_bid={cents(market,'yes_bid')} yes_ask={cents(market,'yes_ask')} "
                              f"no_bid={cents(market,'no_bid')} no_ask={cents(market,'no_ask')} | limit sent={limit}c")
                        if attempts[ticker] >= MAX_ATTEMPTS:
                            entries[ticker] = MAX_ENTRIES_PER_MARKET
                        time.sleep(0.4)
                        continue
                    fill_px = fill_price_cents(resp, side, price)
                    report["fills"] += 1
                    report["cost"] += count * fill_px
                    report["events"].append(
                        f"{now_str()}  {label}  bought {count} {'UP' if side == 'yes' else 'DOWN'} "
                        f"@ {fill_px}c (quote {price}c, limit {limit}c, {left:.0f}s left) | "
                        f"{cushion_text(btc, target, cushion)}")
                    report.setdefault("entries", []).append(
                        {"side": side, "fill_px": fill_px, "left": round(left), "btc": btc,
                         "target": target, "cushion": cushion})
                    entries[ticker] = n + 1
                    pending_ticker = ticker
                    stop_hits = 0
                    position = {"ticker": ticker, "side": side,
                                "count": count, "entry_price": fill_px}

            ya, na = cents(market, "yes_ask"), cents(market, "no_ask")
            pos_txt = (f"{'UP' if position['side'] == 'yes' else 'DOWN'} x{position['count']} @ {position['entry_price']}c"
                       if position else "none")
            print(f"{ticker[-12:]} {left:4.0f}s | UP {ya}c  DOWN {na}c | holding: {pos_txt} "
                  f"| today: {stats['trades']} trades {money(stats['pnl_cents'])}{hold_note}        ", end="\r")
            time.sleep(POLL_SECONDS)

        except requests.HTTPError as e:
            print(f"\nAPI error: {e} -> {e.response.text}")
            time.sleep(3)
        except KeyboardInterrupt:
            print("\nStopped. NOTE: any open position is NOT closed automatically.")
            print(stats_line(stats))
            break
        except Exception as e:
            print(f"\nUnexpected error: {e}")
            time.sleep(3)


if __name__ == "__main__":
    main()
