# Kalshi BTC 15-minute auto-trader

An unofficial Python bot for Kalshi's **Bitcoin Up/Down 15-minute** markets (`KXBTC15M`).
It watches the market, buys the leading side when it reaches your price range late in the
window, and sells if the price falls to your stop.

> **Read this first.** This is not financial advice and is not affiliated with or endorsed by
> Kalshi. Trading can lose money, including everything you deposit. Buying at 90-95% prices
> means a win pays only a few cents per contract while a loss costs most of your stake, so you
> need a very high win rate just to break even (and fees make it harder). Nothing here is proven
> to be profitable. Use money you can afford to lose, and keep `DRY_RUN = True` until you have
> watched it behave correctly.

## What it does

- Watches the current market and waits until **2:30 or less** is left.
- Buys **Up or Down** when that side's ask is between `ENTRY_MIN` and `ENTRY_MAX` and has stayed
  there for `HOLD_SECONDS` in a row (filters out quick spikes).
- Sells if your side's bid falls to `STOP_PRICE` (or `STOP_LOSS_PCT` below your entry).
- Bet size = `STARTING_STAKE` + saved profit/loss, capped at `MAX_STAKE` (compounding).
- Stops opening new trades for the day once you are down `DAILY_LOSS_LIMIT`.
- Prints a trade report per market, keeps a daily win/loss counter, and logs each market to a CSV
  (including how far BTC was past the target, so you can study what works).

## Setup

1. Install [Python 3.10+](https://www.python.org/downloads/) (on Windows tick "Add Python to PATH").
2. Download this repo (green **Code** button, then **Download ZIP**) and unzip it.
3. In that folder run: `pip install -r requirements.txt`
4. In Kalshi, create an **RSA API key**. Save the private key file in the bot folder
   (default name `kalshi_key.key`) and copy the **Key ID**.
5. Give the bot your credentials, either way:
   - edit `KEY_ID` (and `PRIVATE_KEY_PATH` if needed) near the top of `kalshi_bot.py`, or
   - set environment variables `KALSHI_KEY_ID` and `KALSHI_KEY_FILE`.
6. Run: `python kalshi_bot.py` (on Windows you may need `py kalshi_bot.py`).

**Never commit or share your private key.** The `.gitignore` in this repo blocks `*.key` and `*.pem`,
but double-check before every upload.

## Fund the right exchange shard

Kalshi splits balances across "exchange shards". The Bitcoin 15-minute market is a crypto market, and
Kalshi's docs put crypto on shard 2. Orders placed through the API can only use money on that
market's shard, so a normal deposit may sit on a different one and your orders will be rejected with
`insufficient_balance`. At startup the bot prints your money by shard and which shard the market
uses. To move money, try Kalshi's exchange indexes page (https://kalshi.com/account/exchange-indexes)
or run `python move_funds.py`. Kalshi's docs are inconsistent about the transfer API, so the script
may be refused on some accounts.

## Settings (top of `kalshi_bot.py`)

| Setting | Default | Meaning |
|---|---|---|
| `DRY_RUN` | `True` | `True` = print what it would do, place no orders. Set `False` to trade for real. |
| `STARTING_STAKE` | `5.0` | Dollars per trade to start with. |
| `COMPOUND` / `MAX_STAKE` | `True` / `10.0` | Add saved profit/loss to the stake, never bet more than the cap. |
| `DAILY_LOSS_LIMIT` | `10.0` | Stop new trades for the day after losing this much (`0` = off). |
| `ENTRY_MIN` / `ENTRY_MAX` | `90` / `95` | Price range (cents = percent) it will buy in. |
| `HOLD_SECONDS` | `10` | A side must stay in range this long before buying. |
| `WINDOW_START_SEC` / `WINDOW_END_SEC` | `150` / `30` | Only enter between 2:30 and 0:30 left. |
| `STOP_MODE` / `STOP_PRICE` | `"price"` / `70` | Sell when your side's bid reaches 70. `"percent"` uses `STOP_LOSS_PCT`. |
| `BUY_SLIPPAGE` | `4` | Willing to pay up to this many cents above the ask. Lower = fewer fills, better prices. |
| `MAX_ATTEMPTS` | `3` | Unfilled buy attempts per market before giving up. |
| `MIN_CUSHION_USD` | `0` | `0` = only record how far BTC is past the target. Higher = require that much room. |

## Files the bot creates (do not commit)

`kalshi_compound.json` (running profit/loss used for bet sizing), `kalshi_daily_stats.json` (today's
counter), `kalshi_trades.csv` (one row per market). Delete `kalshi_compound.json` to restart
compounding from your starting stake.

## Going live checklist

- Watch at least a few hours in `DRY_RUN = True` and compare the printed orders with Kalshi.
- Use the smallest stake you can (for example `STARTING_STAKE = 2.0`) for the first live trades.
- Stay at the screen for the first trades and compare Kalshi's Portfolio page with what the bot printed.
- Keep your computer awake and online. If the bot stops or loses connection, **open positions are not
  closed for you** and no stop loss runs.
- Do not click inside the Windows console window while it runs; selecting text pauses the program.

## Known limits

- Built against Kalshi's V2 order endpoint, which has already changed once. API changes can break it.
- The BTC price used for the "cushion" comes from Coinbase's public feed and only approximates the
  index Kalshi settles on (which averages the last 60 seconds).
- Stop losses can sell far below the stop price if the market gaps.
- Paper results do not include fees or slippage.

## Troubleshooting

| Message | Likely cause |
|---|---|
| `401` / Unauthorized | Key ID and key file do not match. |
| `410 ... deprecated_v1_order_endpoint` | You are running an old version that uses Kalshi's retired order endpoint. |
| `insufficient_balance` | Your money is on a different exchange shard (see above). |
| `Not filled` repeatedly | The price was beyond your limit; the market may already be decided. |
| `Failed to resolve api.elections.kalshi.com` | Your internet or DNS dropped briefly. |

## License

MIT, see [LICENSE](LICENSE). Replace `YOUR NAME` with your name.
